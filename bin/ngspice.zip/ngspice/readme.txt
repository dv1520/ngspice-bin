The base link to obtain ngspice is http://ngspice.sourceforge.net/download.html

Dirs
linux
linux is build from ngspice-26.tar.gz (https://sourceforge.net/projects/ngspice/files/ng-spice-rework/26/ , https://sourceforge.net/projects/ngspice/files/ng-spice-rework/26/ngspice-26.tar.gz/download )
With the config option

<pre>
./configure --enable-xspice 
</pre>

win
The Windows binaries are http://ngspice.sourceforge.net/experimental/ngspice-26plus-master-32.7z
http://ngspice.sourceforge.net/experimental/ngspice-26plus-scope-inpcom-6-32.7z


The file auto-path-update.txt at the share/ngspice/scripts allow the update of the spinit file. If the ngspice is installed to some custom path, not the defaut one, the file share/ngspice/scripts/spinit contains outdated info, and need to be updated if the xspice is used, for example, for the 'lim' model, which is a base for a simple OpAmp simulation.

