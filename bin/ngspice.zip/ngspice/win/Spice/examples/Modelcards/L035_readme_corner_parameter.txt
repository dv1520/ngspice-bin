The sections cx (x=1...n) in the parameter file contains 
modell parameters for corner simulations.
Each section contains a complete set of modelparameter. 

Case definition (in the meaning of speed, current, gain, stability)
n = normal 
h = high
l = low


      NMOS  PMOS   RN    RP    C     D    NPN   PNP
----------------------------------------------------	  
c0:    n     n     n     n     n     n     n     n
c1:    h     h     h     h     h     l     l     h
c2:    h     l     h     l     n     l     l     h
c3:    l     h     l     h     n     h     h     l
c4:    l     l     l     l     l     h     h     l
